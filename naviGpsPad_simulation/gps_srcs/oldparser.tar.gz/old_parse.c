/* author ycnalin	date 2017/10/11		version 1.0
 * compile with "g++ -std=C11 -o res ParseGps.cpp ParseGps.h"
 */
#include "parse.h"


/* parse the serial port data
 * standard serial data format should be $ddmm.mmmmm,dddmm.mmmmm,m.mm,mm,mmmm#,ie $lat,lon,hdop,numsv,checksum#
 *
 */
bool parse(char* data, double* lat, double* lon, double *HDOP,int numSV) {
	std::string str(data), slat, slon,sHDOP,snumSV,checksum;
	int state = 0;
	int sum = 0;
	if (str.empty()||str.size()< 22) return false;
	for (unsigned int i = 0; i < str.length(); ++i) {
		if (state == 0) {
			if (str[i] == '$') ++state;
		}
		else if (state == 1) {
			if (str[i] != ',')
				slat += str[i];
			else
				++state;
		}
		else if (state == 2) {
			if (str[i] != ',')
				slon += str[i];
			else
				++state;
		}
		else if (state == 3){
			if(str[i] != ',')
				sHDOP += str[i];
			else
				++state;
		}
		else if(state == 4){
			if(str[i] != ',')
				snumSV += str[i];
			else
				++state;
		}
		else if(state == 5){
			if(str[i] != '#'){
				checksum += str[i];
			}
			else
				break;
		}
		else
			break;
	}
	if (state != 5) return false;
	/*transform lat,lon from ddmm.mmmmm to dd.dddd*/
	std::string str1 = slat.substr(0, 2), str2 = slon.substr(0, 3);
	slat.erase(0, 2);
	slon.erase(0, 3);
	double prelat, prelon;
	prelat = stod(str1);
	*lat = stod(slat); //mm.mmmmm
	prelon = stod(str2);
	*lon = stod(slon); //mm.mmmmm
	*lat = prelat + *lat / 60;
	*lon = prelon + *lon / 60;
	return true;
}

 //for debug useage
//int main() {
//	char test[] = "$123.4267,12344.234\n";
//	double lon, lat;
//	if (parse(test, &lat, &lon)) std::cout<<std::setprecision(std::numeric_limits<double>::digits10 + 1)
//	<< lat << " " << lon<<" "<< std::endl;
//	else std::cout << "parse failed, please check the input arguements\n" << std::endl;
//	return 0;
//}

